import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getUserSchedules, createSchedule, updateSchedule, deleteSchedule, getUserTasks, createTask, updateTask, deleteTask, getUserSettings, createOrUpdateUserSettings, getDailyEnergyLevel, setDailyEnergyLevel, updateDailyEnergyLevel, getSelfCareTracking, createSelfCareTracking, updateSelfCareTracking, getWeeklySelfCareTracking } from "./db";

const scheduleInputSchema = z.object({
  title: z.string(),
  type: z.enum(["school", "work", "sleep", "personal"]),
  dayOfWeek: z.number().min(0).max(6),
  startTime: z.string(),
  endTime: z.string(),
  color: z.string(),
  isRecurring: z.boolean().optional(),
  notes: z.string().optional(),
});

const scheduleUpdateSchema = z.object({
  id: z.number(),
  title: z.string().optional(),
  startTime: z.string().optional(),
  endTime: z.string().optional(),
  color: z.string().optional(),
  notes: z.string().optional(),
});

const scheduleDeleteSchema = z.object({
  id: z.number(),
});

const taskInputSchema = z.object({
  subject: z.string(),
  title: z.string(),
  type: z.enum(["essay", "reading", "exam", "presentation", "other"]),
  dueDate: z.date(),
  priority: z.enum(["low", "medium", "high"]).optional(),
  description: z.string().optional(),
});

const taskUpdateSchema = z.object({
  id: z.number(),
  title: z.string().optional(),
  priority: z.enum(["low", "medium", "high"]).optional(),
  isCompleted: z.boolean().optional(),
  description: z.string().optional(),
});

const taskDeleteSchema = z.object({
  id: z.number(),
});

const settingsUpdateSchema = z.object({
  darkMode: z.boolean().optional(),
  enableDeadlineReminder24h: z.boolean().optional(),
  enableDeadlineReminder3h: z.boolean().optional(),
  enableClassReminder30m: z.boolean().optional(),
  enableBackToBackAlert: z.boolean().optional(),
  restDayStart: z.number().optional(),
  restDayEnd: z.number().optional(),
  workShiftStart: z.string().optional(),
  workShiftEnd: z.string().optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  schedule: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserSchedules(ctx.user.id);
    }),
    create: protectedProcedure
      .input(scheduleInputSchema)
      .mutation(async ({ ctx, input }) => {
        return createSchedule({
          userId: ctx.user.id,
          ...input,
          isRecurring: input.isRecurring ? 1 : 0,
        });
      }),
    update: protectedProcedure
      .input(scheduleUpdateSchema)
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        return updateSchedule(id, updates);
      }),
    delete: protectedProcedure
      .input(scheduleDeleteSchema)
      .mutation(async ({ input }) => {
        return deleteSchedule(input.id);
      }),
  }),

  task: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserTasks(ctx.user.id);
    }),
    create: protectedProcedure
      .input(taskInputSchema)
      .mutation(async ({ ctx, input }) => {
        return createTask({
          userId: ctx.user.id,
          ...input,
          isCompleted: 0,
        });
      }),
    update: protectedProcedure
      .input(taskUpdateSchema)
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        const processedUpdates = {
          ...updates,
          isCompleted: updates.isCompleted !== undefined ? (updates.isCompleted ? 1 : 0) : undefined,
        };
        return updateTask(id, processedUpdates);
      }),
    delete: protectedProcedure
      .input(taskDeleteSchema)
      .mutation(async ({ input }) => {
        return deleteTask(input.id);
      }),
  }),

  settings: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      return getUserSettings(ctx.user.id);
    }),
    update: protectedProcedure
      .input(settingsUpdateSchema)
      .mutation(async ({ ctx, input }) => {
        const processedInput = {
          ...input,
          darkMode: input.darkMode !== undefined ? (input.darkMode ? 1 : 0) : undefined,
          enableDeadlineReminder24h: input.enableDeadlineReminder24h !== undefined ? (input.enableDeadlineReminder24h ? 1 : 0) : undefined,
          enableDeadlineReminder3h: input.enableDeadlineReminder3h !== undefined ? (input.enableDeadlineReminder3h ? 1 : 0) : undefined,
          enableClassReminder30m: input.enableClassReminder30m !== undefined ? (input.enableClassReminder30m ? 1 : 0) : undefined,
          enableBackToBackAlert: input.enableBackToBackAlert !== undefined ? (input.enableBackToBackAlert ? 1 : 0) : undefined,
        };
        return createOrUpdateUserSettings(ctx.user.id, processedInput);
      }),
  }),

  energy: router({
    getToday: protectedProcedure.query(async ({ ctx }) => {
      const today = new Date().toISOString().split('T')[0];
      return await getDailyEnergyLevel(ctx.user.id, today);
    }),
    setToday: protectedProcedure
      .input(z.object({
        energyLevel: z.enum(["low", "medium", "high"]),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const today = new Date().toISOString().split('T')[0];
        const existing = await getDailyEnergyLevel(ctx.user.id, today);
        if (existing) {
          return await updateDailyEnergyLevel(existing.id, input);
        }
        return await setDailyEnergyLevel({
          userId: ctx.user.id,
          date: today,
          energyLevel: input.energyLevel,
          notes: input.notes,
        });
      }),
  }),

  selfCare: router({
    getToday: protectedProcedure.query(async ({ ctx }) => {
      const today = new Date().toISOString().split('T')[0];
      return await getSelfCareTracking(ctx.user.id, today);
    }),
    create: protectedProcedure
      .input(z.object({
        sleepHours: z.number().optional(),
        sleepQuality: z.enum(["poor", "fair", "good", "excellent"]).optional(),
        studySessionMinutes: z.number().optional(),
        studySessionCount: z.number().optional(),
        breakMinutes: z.number().optional(),
        moodNote: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const today = new Date().toISOString().split('T')[0];
        return await createSelfCareTracking({
          userId: ctx.user.id,
          date: today,
          sleepHours: input.sleepHours,
          sleepQuality: input.sleepQuality,
          studySessionMinutes: input.studySessionMinutes || 0,
          studySessionCount: input.studySessionCount || 0,
          breakMinutes: input.breakMinutes || 0,
          moodNote: input.moodNote,
        });
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        sleepHours: z.number().optional(),
        sleepQuality: z.enum(["poor", "fair", "good", "excellent"]).optional(),
        studySessionMinutes: z.number().optional(),
        studySessionCount: z.number().optional(),
        breakMinutes: z.number().optional(),
        moodNote: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        return await updateSelfCareTracking(id, updates);
      }),
    getWeekly: protectedProcedure.query(async ({ ctx }) => {
      const today = new Date();
      const startOfWeek = new Date(today);
      startOfWeek.setDate(today.getDate() - today.getDay());
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(startOfWeek.getDate() + 6);
      
      const startStr = startOfWeek.toISOString().split('T')[0];
      const endStr = endOfWeek.toISOString().split('T')[0];
      
      return await getWeeklySelfCareTracking(ctx.user.id, startStr, endStr);
    }),
  }),
});

export type AppRouter = typeof appRouter;
