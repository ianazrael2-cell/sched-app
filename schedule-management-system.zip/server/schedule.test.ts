import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("Schedule Operations", () => {
  it("should list schedules for a user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const schedules = await caller.schedule.list();
    expect(Array.isArray(schedules)).toBe(true);
  });

  it("should create a schedule", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.schedule.create({
      title: "Math Class",
      type: "school",
      dayOfWeek: 0,
      startTime: "09:00",
      endTime: "10:30",
      color: "#3b82f6",
    });

    expect(result).toBeDefined();
  });

  it("should create a work schedule", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.schedule.create({
      title: "Night Shift",
      type: "work",
      dayOfWeek: 1,
      startTime: "22:00",
      endTime: "06:00",
      color: "#a855f7",
    });

    expect(result).toBeDefined();
  });

  it("should create a sleep schedule", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.schedule.create({
      title: "Sleep",
      type: "sleep",
      dayOfWeek: 2,
      startTime: "08:00",
      endTime: "16:00",
      color: "#6b7280",
    });

    expect(result).toBeDefined();
  });

  it("should update a schedule", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create first
    const created = await caller.schedule.create({
      title: "Original Title",
      type: "school",
      dayOfWeek: 0,
      startTime: "09:00",
      endTime: "10:00",
      color: "#3b82f7",
    });

    // Update
    const result = await caller.schedule.update({
      id: 1,
      title: "Updated Title",
      startTime: "10:00",
      endTime: "11:00",
    });

    expect(result).toBeDefined();
  });

  it("should delete a schedule", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.schedule.delete({ id: 1 });
    expect(result).toBeDefined();
  });
});

describe("Task Operations", () => {
  it("should list tasks for a user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const tasks = await caller.task.list();
    expect(Array.isArray(tasks)).toBe(true);
  });

  it("should create a task", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 7);

    const result = await caller.task.create({
      subject: "English Literature",
      title: "Essay on Shakespeare",
      type: "essay",
      dueDate,
      priority: "high",
      description: "Write a 2000-word essay",
    });

    expect(result).toBeDefined();
  });

  it("should create different task types", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 3);

    const taskTypes = ["essay", "reading", "exam", "presentation", "other"];

    for (const type of taskTypes) {
      const result = await caller.task.create({
        subject: "Test Subject",
        title: `Task: ${type}`,
        type: type as any,
        dueDate,
        priority: "medium",
      });
      expect(result).toBeDefined();
    }
  });

  it("should create tasks with different priorities", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 5);

    const priorities = ["low", "medium", "high"];

    for (const priority of priorities) {
      const result = await caller.task.create({
        subject: "Test Subject",
        title: `Priority: ${priority}`,
        type: "essay",
        dueDate,
        priority: priority as any,
      });
      expect(result).toBeDefined();
    }
  });

  it("should update a task", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.task.update({
      id: 1,
      title: "Updated Task Title",
      priority: "high",
      isCompleted: true,
    });

    expect(result).toBeDefined();
  });

  it("should mark task as completed", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.task.update({
      id: 1,
      isCompleted: true,
    });

    expect(result).toBeDefined();
  });

  it("should delete a task", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.task.delete({ id: 1 });
    expect(result).toBeDefined();
  });
});

describe("Settings Operations", () => {
  it("should get user settings", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const settings = await caller.settings.get();
    expect(settings).toBeDefined();
  });

  it("should update notification settings", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.settings.update({
      enableDeadlineReminder24h: false,
      enableDeadlineReminder3h: true,
      enableClassReminder30m: false,
      enableBackToBackAlert: true,
    });

    expect(result).toBeDefined();
  });

  it("should update work shift times", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.settings.update({
      workShiftStart: "22:00",
      workShiftEnd: "08:00",
    });

    expect(result).toBeDefined();
  });

  it("should update rest days", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.settings.update({
      restDayStart: 5,
      restDayEnd: 6,
    });

    expect(result).toBeDefined();
  });

  it("should update dark mode setting", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.settings.update({
      darkMode: true,
    });

    expect(result).toBeDefined();
  });

  it("should update all settings at once", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.settings.update({
      darkMode: true,
      enableDeadlineReminder24h: true,
      enableDeadlineReminder3h: true,
      enableClassReminder30m: true,
      enableBackToBackAlert: true,
      restDayStart: 5,
      restDayEnd: 6,
      workShiftStart: "22:00",
      workShiftEnd: "08:00",
    });

    expect(result).toBeDefined();
  });
});

describe("Authentication", () => {
  it("should get current user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const user = await caller.auth.me();
    expect(user).toBeDefined();
    expect(user?.id).toBe(1);
    expect(user?.email).toBe("test@example.com");
  });

  it("should logout user", async () => {
    const { ctx } = createAuthContext();
    const clearedCookies: any[] = [];

    ctx.res = {
      clearCookie: (name: string, options: any) => {
        clearedCookies.push({ name, options });
      },
    } as any;

    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();

    expect(result.success).toBe(true);
    expect(clearedCookies.length).toBeGreaterThan(0);
  });
});
