import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const schedules = mysqlTable("schedules", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["school", "work", "sleep", "personal"]).notNull(),
  dayOfWeek: int("dayOfWeek").notNull(), // 0 = Monday, 6 = Sunday
  startTime: varchar("startTime", { length: 5 }).notNull(), // HH:MM format
  endTime: varchar("endTime", { length: 5 }).notNull(), // HH:MM format
  color: varchar("color", { length: 7 }).notNull(), // hex color
  isRecurring: int("isRecurring").default(0).notNull(), // 0 = false, 1 = true
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Schedule = typeof schedules.$inferSelect;
export type InsertSchedule = typeof schedules.$inferInsert;

export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  subject: varchar("subject", { length: 255 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["essay", "reading", "exam", "presentation", "other"]).notNull(),
  dueDate: timestamp("dueDate").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high"]).default("medium").notNull(),
  isCompleted: int("isCompleted").default(0).notNull(), // 0 = false, 1 = true
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

export const userSettings = mysqlTable("userSettings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  darkMode: int("darkMode").default(1).notNull(), // 0 = false, 1 = true
  enableDeadlineReminder24h: int("enableDeadlineReminder24h").default(1).notNull(),
  enableDeadlineReminder3h: int("enableDeadlineReminder3h").default(1).notNull(),
  enableClassReminder30m: int("enableClassReminder30m").default(1).notNull(),
  enableBackToBackAlert: int("enableBackToBackAlert").default(1).notNull(),
  restDayStart: int("restDayStart").default(5).notNull(), // 0 = Monday, 5 = Saturday
  restDayEnd: int("restDayEnd").default(6).notNull(), // 0 = Monday, 6 = Sunday
  workShiftStart: varchar("workShiftStart", { length: 5 }).default("22:00").notNull(), // HH:MM
  workShiftEnd: varchar("workShiftEnd", { length: 5 }).default("08:00").notNull(), // HH:MM
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = typeof userSettings.$inferInsert;

export const dailyEnergyLevels = mysqlTable("dailyEnergyLevels", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD format
  energyLevel: mysqlEnum("energyLevel", ["low", "medium", "high"]).notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DailyEnergyLevel = typeof dailyEnergyLevels.$inferSelect;
export type InsertDailyEnergyLevel = typeof dailyEnergyLevels.$inferInsert;

export const selfCareTracking = mysqlTable("selfCareTracking", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD format
  sleepHours: int("sleepHours"), // in minutes
  sleepQuality: mysqlEnum("sleepQuality", ["poor", "fair", "good", "excellent"]),
  studySessionMinutes: int("studySessionMinutes").default(0).notNull(),
  studySessionCount: int("studySessionCount").default(0).notNull(),
  breakMinutes: int("breakMinutes").default(0).notNull(),
  moodNote: text("moodNote"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SelfCareTracking = typeof selfCareTracking.$inferSelect;
export type InsertSelfCareTracking = typeof selfCareTracking.$inferInsert;