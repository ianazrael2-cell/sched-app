CREATE TABLE `dailyEnergyLevels` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`date` varchar(10) NOT NULL,
	`energyLevel` enum('low','medium','high') NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dailyEnergyLevels_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `selfCareTracking` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`date` varchar(10) NOT NULL,
	`sleepHours` int,
	`sleepQuality` enum('poor','fair','good','excellent'),
	`studySessionMinutes` int NOT NULL DEFAULT 0,
	`studySessionCount` int NOT NULL DEFAULT 0,
	`breakMinutes` int NOT NULL DEFAULT 0,
	`moodNote` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `selfCareTracking_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `dailyEnergyLevels` ADD CONSTRAINT `dailyEnergyLevels_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `selfCareTracking` ADD CONSTRAINT `selfCareTracking_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;