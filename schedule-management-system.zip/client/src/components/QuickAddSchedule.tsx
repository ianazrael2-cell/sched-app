import React, { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, BookOpen, Briefcase, Moon, Sparkles } from "lucide-react";
import { toast } from "sonner";

interface QuickAddScheduleProps {
  isOpen: boolean;
  onClose: () => void;
  dayOfWeek?: number;
  onScheduleAdded?: () => void;
}

export default function QuickAddSchedule({
  isOpen,
  onClose,
  dayOfWeek = 0,
  onScheduleAdded,
}: QuickAddScheduleProps) {
  const [title, setTitle] = useState("");
  const [type, setType] = useState<"school" | "work" | "sleep" | "personal">("school");
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("10:00");

  const createMutation = trpc.schedule.create.useMutation();

  const categoryDefaults = {
    school: { duration: 1.5, icon: <BookOpen className="w-5 h-5" /> },
    work: { duration: 8, icon: <Briefcase className="w-5 h-5" /> },
    sleep: { duration: 8, icon: <Moon className="w-5 h-5" /> },
    personal: { duration: 2, icon: <Sparkles className="w-5 h-5" /> },
  };

  const handleTypeChange = (newType: string) => {
    setType(newType as typeof type);
    // Auto-adjust end time based on category
    const duration = categoryDefaults[newType as typeof type].duration;
    const [hours, minutes] = startTime.split(":").map(Number);
    const endHours = Math.floor((hours + duration) % 24);
    const endMinutes = minutes;
    setEndTime(
      `${String(endHours).padStart(2, "0")}:${String(endMinutes).padStart(2, "0")}`
    );
  };

  const handleQuickAdd = async () => {
    if (!title.trim()) {
      toast.error("Please enter a schedule title");
      return;
    }

    try {
      await createMutation.mutateAsync({
        title,
        type,
        dayOfWeek,
        startTime,
        endTime,
        color: getColorForType(type),
      });
      toast.success("Schedule added quickly!");
      setTitle("");
      setType("school");
      onClose();
      onScheduleAdded?.();
    } catch (error) {
      toast.error("Failed to add schedule");
    }
  };

  const getColorForType = (t: string): string => {
    const colors: Record<string, string> = {
      school: "#3b82f6",
      work: "#9333ea",
      sleep: "#ec4899",
      personal: "#a78bfa",
    };
    return colors[t] || "#3b82f6";
  };

  if (!isOpen) return null;

  return (
    <div className="quick-add-modal" onClick={onClose}>
      <div className="quick-add-sheet" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-foreground">Quick Add Schedule</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-muted rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Title */}
          <div>
            <Label className="text-sm">What are you scheduling?</Label>
            <Input
              placeholder="e.g., Math Class, Work Shift, Sleep"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-1"
              autoFocus
            />
          </div>

          {/* Category Quick Select */}
          <div>
            <Label className="text-sm mb-2 block">Category</Label>
            <div className="grid grid-cols-4 gap-2">
              {Object.entries(categoryDefaults).map(([cat, { icon }]) => (
                <button
                  key={cat}
                  onClick={() => handleTypeChange(cat)}
                  className={`category-pill category-pill-${cat} ${
                    type === cat ? "category-pill-active" : ""
                  } justify-center`}
                >
                  {icon}
                </button>
              ))}
            </div>
          </div>

          {/* Time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-sm">Start</Label>
              <Input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label className="text-sm">End</Label>
              <Input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="mt-1"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-4">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handleQuickAdd}
              className="gradient-button flex-1"
              disabled={createMutation.isPending}
            >
              {createMutation.isPending ? "Adding..." : "Add Schedule"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
