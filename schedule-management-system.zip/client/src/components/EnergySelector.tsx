import React from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Zap, Battery, Flame } from "lucide-react";

type EnergyLevel = "low" | "medium" | "high";

interface EnergySelectorProps {
  onEnergyChange?: (level: EnergyLevel) => void;
}

export default function EnergySelector({ onEnergyChange }: EnergySelectorProps) {
  const { data: todayEnergy, refetch } = trpc.energy.getToday.useQuery();
  const setEnergyMutation = trpc.energy.setToday.useMutation();
  const [selectedEnergy, setSelectedEnergy] = React.useState<EnergyLevel | null>(
    (todayEnergy?.energyLevel as EnergyLevel) || null
  );

  React.useEffect(() => {
    if (todayEnergy?.energyLevel) {
      setSelectedEnergy(todayEnergy.energyLevel as EnergyLevel);
    }
  }, [todayEnergy]);

  const handleEnergySelect = async (level: EnergyLevel) => {
    try {
      setSelectedEnergy(level);
      await setEnergyMutation.mutateAsync({
        energyLevel: level,
      });
      toast.success(`Energy level set to ${level}`);
      refetch();
      onEnergyChange?.(level);
    } catch (error) {
      toast.error("Failed to set energy level");
      setSelectedEnergy(todayEnergy?.energyLevel as EnergyLevel || null);
    }
  };

  const energyOptions: Array<{
    level: EnergyLevel;
    label: string;
    icon: React.ReactNode;
    description: string;
    color: string;
  }> = [
    {
      level: "low",
      label: "Low",
      icon: <Battery className="w-5 h-5" />,
      description: "Rest & light tasks",
      color: "blue",
    },
    {
      level: "medium",
      label: "Medium",
      icon: <Zap className="w-5 h-5" />,
      description: "Normal tasks",
      color: "yellow",
    },
    {
      level: "high",
      label: "High",
      icon: <Flame className="w-5 h-5" />,
      description: "Challenging tasks",
      color: "pink",
    },
  ];

  return (
    <div className="space-y-2">
      <h3 className="text-sm font-semibold text-muted-foreground">How's your energy today?</h3>
      <div className="energy-selector">
        {energyOptions.map((option) => (
          <button
            key={option.level}
            onClick={() => handleEnergySelect(option.level)}
            className={`energy-button energy-button-${option.level} ${
              selectedEnergy === option.level ? "energy-button-active" : ""
            }`}
          >
            <div className="flex flex-col items-center gap-1">
              {option.icon}
              <span className="text-xs">{option.label}</span>
            </div>
          </button>
        ))}
      </div>
      {selectedEnergy && (
        <p className="text-xs text-muted-foreground text-center">
          {energyOptions.find((o) => o.level === selectedEnergy)?.description}
        </p>
      )}
    </div>
  );
}
