import React from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Moon, BookOpen, Smile } from "lucide-react";

export default function SelfCareTracker() {
  const { data: todayCare, refetch } = trpc.selfCare.getToday.useQuery();
  const { data: weeklyCare } = trpc.selfCare.getWeekly.useQuery();
  const createMutation = trpc.selfCare.create.useMutation();
  const updateMutation = trpc.selfCare.update.useMutation();

  const [sleepHours, setSleepHours] = React.useState<number | string>(
    todayCare?.sleepHours ? Math.round(todayCare.sleepHours / 60) : ""
  );
  const [sleepQuality, setSleepQuality] = React.useState(todayCare?.sleepQuality || "");
  const [studyMinutes, setStudyMinutes] = React.useState<number | string>(
    todayCare?.studySessionMinutes || ""
  );
  const [moodNote, setMoodNote] = React.useState(todayCare?.moodNote || "");

  const handleSave = async () => {
    try {
      const data = {
        sleepHours: sleepHours ? parseInt(sleepHours.toString()) * 60 : undefined,
        sleepQuality: (sleepQuality as "poor" | "fair" | "good" | "excellent" | undefined) || undefined,
        studySessionMinutes: studyMinutes ? parseInt(studyMinutes.toString()) : undefined,
        moodNote: moodNote || undefined,
      };

      if (todayCare?.id) {
        await updateMutation.mutateAsync({ id: todayCare.id, ...data });
      } else {
        await createMutation.mutateAsync(data);
      }
      toast.success("Self-care logged successfully");
      refetch();
    } catch (error) {
      toast.error("Failed to save self-care data");
    }
  };

  const weeklySleepAvg =
    weeklyCare && weeklyCare.length > 0
      ? Math.round(
          weeklyCare.reduce((sum, day) => sum + (day.sleepHours || 0), 0) / weeklyCare.length / 60
        )
      : 0;

  const weeklyStudyTotal =
    weeklyCare && weeklyCare.length > 0
      ? Math.round(weeklyCare.reduce((sum, day) => sum + (day.studySessionMinutes || 0), 0) / 60)
      : 0;

  return (
    <div className="space-y-4">
      <Card className="self-care-card">
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
            <Moon className="w-5 h-5 text-pink-500" />
            Today's Self-Care
          </h3>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm">Sleep Hours</Label>
              <Input
                type="number"
                min="0"
                max="24"
                value={sleepHours}
                onChange={(e) => setSleepHours(e.target.value)}
                placeholder="Hours"
                className="mt-1"
              />
            </div>
            <div>
              <Label className="text-sm">Sleep Quality</Label>
              <Select value={sleepQuality} onValueChange={setSleepQuality}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select quality" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="poor">Poor</SelectItem>
                  <SelectItem value="fair">Fair</SelectItem>
                  <SelectItem value="good">Good</SelectItem>
                  <SelectItem value="excellent">Excellent</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="text-sm flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Study Time (minutes)
            </Label>
            <Input
              type="number"
              min="0"
              value={studyMinutes}
              onChange={(e) => setStudyMinutes(e.target.value)}
              placeholder="Minutes"
              className="mt-1"
            />
          </div>

          <div>
            <Label className="text-sm flex items-center gap-2">
              <Smile className="w-4 h-4" />
              Mood Note
            </Label>
            <Input
              type="text"
              value={moodNote}
              onChange={(e) => setMoodNote(e.target.value)}
              placeholder="How are you feeling?"
              className="mt-1"
            />
          </div>

          <Button onClick={handleSave} className="gradient-button w-full">
            Save Self-Care Log
          </Button>
        </div>
      </Card>

      {weeklyCare && weeklyCare.length > 0 && (
        <Card className="self-care-card">
          <h3 className="text-lg font-bold text-foreground mb-4">Weekly Summary</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-lg bg-blue-500/10 p-4">
              <p className="text-sm text-muted-foreground">Avg Sleep</p>
              <p className="text-2xl font-bold text-blue-600 dark:text-blue-300">{weeklySleepAvg}h</p>
            </div>
            <div className="rounded-lg bg-purple-500/10 p-4">
              <p className="text-sm text-muted-foreground">Study Time</p>
              <p className="text-2xl font-bold text-purple-600 dark:text-purple-300">
                {weeklyStudyTotal}h
              </p>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-4">
            💡 You're doing great! Keep up the balance between work and rest.
          </p>
        </Card>
      )}
    </div>
  );
}
