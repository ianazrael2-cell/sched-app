import React from "react";
import { BookOpen, Briefcase, Moon, Sparkles } from "lucide-react";

type FocusCategory = "all" | "school" | "work" | "sleep" | "personal";

interface FocusModeProps {
  activeFilter: FocusCategory;
  onFilterChange: (filter: FocusCategory) => void;
}

export default function FocusMode({ activeFilter, onFilterChange }: FocusModeProps) {
  const categories: Array<{
    id: FocusCategory;
    label: string;
    icon: React.ReactNode;
    color: string;
  }> = [
    { id: "all", label: "All", icon: <Sparkles className="w-4 h-4" />, color: "purple" },
    { id: "school", label: "School", icon: <BookOpen className="w-4 h-4" />, color: "blue" },
    { id: "work", label: "Work", icon: <Briefcase className="w-4 h-4" />, color: "purple" },
    { id: "sleep", label: "Sleep", icon: <Moon className="w-4 h-4" />, color: "pink" },
  ];

  return (
    <div className="flex flex-wrap gap-2">
      {categories.map((category) => (
        <button
          key={category.id}
          onClick={() => onFilterChange(category.id)}
          className={`category-pill category-pill-${category.id} ${
            activeFilter === category.id ? "category-pill-active" : ""
          }`}
        >
          {category.icon}
          <span>{category.label}</span>
        </button>
      ))}
    </div>
  );
}
