import React from "react";
import { Heart, AlertCircle } from "lucide-react";
import { Card } from "@/components/ui/card";

interface DailyBalanceIndicatorProps {
  workHours: number;
  studyHours: number;
  sleepHours: number;
}

export default function DailyBalanceIndicator({
  workHours,
  studyHours,
  sleepHours,
}: DailyBalanceIndicatorProps) {
  const totalActiveHours = workHours + studyHours;
  const recommendedSleep = 8;

  // Determine balance status
  let status: "balanced" | "heavy" | "overloaded";
  let statusEmoji: string;
  let statusMessage: string;

  if (totalActiveHours > 12 || sleepHours < 5) {
    status = "overloaded";
    statusEmoji = "⚠️";
    statusMessage = "You're doing a lot today. Remember to take breaks!";
  } else if (totalActiveHours > 10 || sleepHours < 6) {
    status = "heavy";
    statusEmoji = "💜";
    statusMessage = "Busy day ahead. Stay hydrated and take care of yourself.";
  } else {
    status = "balanced";
    statusEmoji = "💗";
    statusMessage = "Great balance! You're taking care of yourself.";
  }

  const sleepStatus =
    sleepHours >= recommendedSleep
      ? "Great sleep planned"
      : sleepHours >= 6
        ? "Adequate sleep"
        : "Consider more sleep";

  return (
    <Card className="balance-indicator">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-semibold text-foreground flex items-center gap-2">
            <span className="text-xl">{statusEmoji}</span>
            Daily Balance
          </h3>
          <p className="text-sm text-muted-foreground mt-1">{statusMessage}</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 mt-4">
        <div className="rounded-lg bg-purple-500/10 p-3">
          <p className="text-xs text-muted-foreground">Work</p>
          <p className="text-lg font-bold text-purple-600 dark:text-purple-300">
            {workHours.toFixed(1)}h
          </p>
        </div>
        <div className="rounded-lg bg-blue-500/10 p-3">
          <p className="text-xs text-muted-foreground">Study</p>
          <p className="text-lg font-bold text-blue-600 dark:text-blue-300">
            {studyHours.toFixed(1)}h
          </p>
        </div>
        <div className="rounded-lg bg-pink-500/10 p-3">
          <p className="text-xs text-muted-foreground">Sleep</p>
          <p className="text-lg font-bold text-pink-600 dark:text-pink-300">
            {sleepHours.toFixed(1)}h
          </p>
        </div>
      </div>

      {sleepHours < 6 && (
        <div className="soft-warning flex items-start gap-2">
          <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-medium text-sm">Sleep reminder</p>
            <p className="text-xs mt-0.5">
              {sleepHours < 5
                ? "You might be exhausted tomorrow. Try to get more rest."
                : "A bit more sleep would help you feel better."}
            </p>
          </div>
        </div>
      )}

      {totalActiveHours > 12 && (
        <div className="soft-warning flex items-start gap-2">
          <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-medium text-sm">Busy day ahead</p>
            <p className="text-xs mt-0.5">
              Consider moving some tasks to another day or taking longer breaks.
            </p>
          </div>
        </div>
      )}
    </Card>
  );
}
