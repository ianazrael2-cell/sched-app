import React, { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import ScheduleDashboardLayout from "@/components/ScheduleDashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Save } from "lucide-react";

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

export default function Settings() {
  const { data: settings, refetch } = trpc.settings.get.useQuery();
  const updateSettingsMutation = trpc.settings.update.useMutation();

  const [formData, setFormData] = useState({
    darkMode: true,
    enableDeadlineReminder24h: true,
    enableDeadlineReminder3h: true,
    enableClassReminder30m: true,
    enableBackToBackAlert: true,
    restDayStart: 5,
    restDayEnd: 6,
    workShiftStart: "22:00",
    workShiftEnd: "08:00",
  });

  useEffect(() => {
    if (settings) {
      setFormData({
        darkMode: settings.darkMode === 1,
        enableDeadlineReminder24h: settings.enableDeadlineReminder24h === 1,
        enableDeadlineReminder3h: settings.enableDeadlineReminder3h === 1,
        enableClassReminder30m: settings.enableClassReminder30m === 1,
        enableBackToBackAlert: settings.enableBackToBackAlert === 1,
        restDayStart: settings.restDayStart,
        restDayEnd: settings.restDayEnd,
        workShiftStart: settings.workShiftStart,
        workShiftEnd: settings.workShiftEnd,
      });
    }
  }, [settings]);

  const handleSave = async () => {
    try {
      await updateSettingsMutation.mutateAsync(formData);
      toast.success("Settings saved successfully");
      refetch();
    } catch (error) {
      toast.error("Failed to save settings");
    }
  };

  return (
    <ScheduleDashboardLayout>
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-3xl font-bold text-foreground">Settings</h1>
            <p className="text-muted-foreground mt-1">Customize your schedule management experience</p>
          </div>

          {/* Notification Preferences */}
          <Card className="p-6 border border-border">
            <h2 className="text-xl font-bold text-foreground mb-4">Notifications</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">24-Hour Deadline Reminder</Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Get notified 24 hours before a deadline
                  </p>
                </div>
                <Switch
                  checked={formData.enableDeadlineReminder24h}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, enableDeadlineReminder24h: checked })
                  }
                />
              </div>

              <div className="border-t border-border pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">3-Hour Deadline Reminder</Label>
                    <p className="text-sm text-muted-foreground mt-1">
                      Get notified 3 hours before a deadline
                    </p>
                  </div>
                  <Switch
                    checked={formData.enableDeadlineReminder3h}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, enableDeadlineReminder3h: checked })
                    }
                  />
                </div>
              </div>

              <div className="border-t border-border pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Class Reminder (30 minutes before)</Label>
                    <p className="text-sm text-muted-foreground mt-1">
                      Get notified 30 minutes before your classes
                    </p>
                  </div>
                  <Switch
                    checked={formData.enableClassReminder30m}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, enableClassReminder30m: checked })
                    }
                  />
                </div>
              </div>

              <div className="border-t border-border pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Back-to-Back Task Alert</Label>
                    <p className="text-sm text-muted-foreground mt-1">
                      Alert when you have consecutive tasks with no break
                    </p>
                  </div>
                  <Switch
                    checked={formData.enableBackToBackAlert}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, enableBackToBackAlert: checked })
                    }
                  />
                </div>
              </div>
            </div>
          </Card>

          {/* Work Schedule */}
          <Card className="p-6 border border-border">
            <h2 className="text-xl font-bold text-foreground mb-4">Work Schedule</h2>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Set your typical graveyard shift hours for better scheduling insights
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Shift Start Time</Label>
                  <Input
                    type="time"
                    value={formData.workShiftStart}
                    onChange={(e) =>
                      setFormData({ ...formData, workShiftStart: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label>Shift End Time</Label>
                  <Input
                    type="time"
                    value={formData.workShiftEnd}
                    onChange={(e) =>
                      setFormData({ ...formData, workShiftEnd: e.target.value })
                    }
                  />
                </div>
              </div>
            </div>
          </Card>

          {/* Rest Days */}
          <Card className="p-6 border border-border">
            <h2 className="text-xl font-bold text-foreground mb-4">Rest Days</h2>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Configure which days are your rest days for better burnout prevention
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Rest Day Start</Label>
                  <Select
                    value={formData.restDayStart.toString()}
                    onValueChange={(v) =>
                      setFormData({ ...formData, restDayStart: parseInt(v) })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {DAYS.map((day, idx) => (
                        <SelectItem key={idx} value={idx.toString()}>
                          {day}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Rest Day End</Label>
                  <Select
                    value={formData.restDayEnd.toString()}
                    onValueChange={(v) =>
                      setFormData({ ...formData, restDayEnd: parseInt(v) })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {DAYS.map((day, idx) => (
                        <SelectItem key={idx} value={idx.toString()}>
                          {day}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded">
                <p className="text-sm text-blue-900 dark:text-blue-200">
                  Rest days: {DAYS[formData.restDayStart]} to {DAYS[formData.restDayEnd]}
                </p>
              </div>
            </div>
          </Card>

          {/* Appearance */}
          <Card className="p-6 border border-border">
            <h2 className="text-xl font-bold text-foreground mb-4">Appearance</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">Dark Mode</Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Use dark theme for better night-time visibility
                  </p>
                </div>
                <Switch
                  checked={formData.darkMode}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, darkMode: checked })
                  }
                />
              </div>
            </div>
          </Card>

          {/* Save Button */}
          <div className="flex gap-4">
            <Button onClick={handleSave} className="gap-2" size="lg">
              <Save size={18} />
              Save Settings
            </Button>
            <Button
              variant="outline"
              onClick={() => refetch()}
              size="lg"
            >
              Reset
            </Button>
          </div>

          {/* Info */}
          <Card className="p-4 bg-blue-500/10 border-blue-500/30">
            <p className="text-sm text-blue-900 dark:text-blue-200">
              💡 <strong>Tip:</strong> These settings help the system understand your schedule better and provide more accurate reminders and suggestions.
            </p>
          </Card>
        </div>
      </div>
    </ScheduleDashboardLayout>
  );
}
