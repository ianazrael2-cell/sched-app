import React, { useMemo } from "react";
import { trpc } from "@/lib/trpc";
import ScheduleDashboardLayout from "@/components/ScheduleDashboardLayout";
import EnergySelector from "@/components/EnergySelector";
import SelfCareTracker from "@/components/SelfCareTracker";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Clock, AlertCircle, Moon } from "lucide-react";
import { useLocation } from "wouter";
import { format, isToday, startOfDay, endOfDay, differenceInHours, differenceInMinutes } from "date-fns";

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { data: schedules = [] } = trpc.schedule.list.useQuery();
  const { data: tasks = [] } = trpc.task.list.useQuery();
  const { data: settings } = trpc.settings.get.useQuery();

  // Get today's schedules
  const todaySchedules = useMemo(() => {
    const today = new Date();
    const dayOfWeek = today.getDay() === 0 ? 6 : today.getDay() - 1; // Convert to 0=Monday
    return schedules.filter((s) => s.dayOfWeek === dayOfWeek);
  }, [schedules]);

  // Get upcoming tasks (next 7 days)
  const upcomingTasks = useMemo(() => {
    const now = new Date();
    const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    return tasks
      .filter((t) => !t.isCompleted && new Date(t.dueDate) >= now && new Date(t.dueDate) <= nextWeek)
      .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
      .slice(0, 5);
  }, [tasks]);

  // Get next deadline
  const nextDeadline = useMemo(() => {
    const now = new Date();
    const incomplete = tasks.filter((t) => !t.isCompleted);
    if (incomplete.length === 0) return null;
    const sorted = incomplete.sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
    return sorted[0];
  }, [tasks]);

  // Calculate time until next deadline
  const timeUntilDeadline = useMemo(() => {
    if (!nextDeadline) return null;
    const now = new Date();
    const due = new Date(nextDeadline.dueDate);
    const hours = differenceInHours(due, now);
    const minutes = differenceInMinutes(due, now) % 60;
    return { hours, minutes, days: Math.floor(hours / 24) };
  }, [nextDeadline]);

  // Calculate sleep summary
  const sleepSummary = useMemo(() => {
    const sleepBlocks = todaySchedules.filter((s) => s.type === "sleep");
    const totalMinutes = sleepBlocks.reduce((acc, block) => {
      const [startH, startM] = block.startTime.split(":").map(Number);
      const [endH, endM] = block.endTime.split(":").map(Number);
      let duration = (endH - startH) * 60 + (endM - startM);
      if (duration < 0) duration += 24 * 60; // Handle overnight
      return acc + duration;
    }, 0);
    return {
      hours: Math.floor(totalMinutes / 60),
      minutes: totalMinutes % 60,
      blocks: sleepBlocks.length,
    };
  }, [todaySchedules]);

  // Check for rest day
  const isRestDay = useMemo(() => {
    const today = new Date();
    const dayOfWeek = today.getDay() === 0 ? 6 : today.getDay() - 1;
    const restStart = settings?.restDayStart ?? 5;
    const restEnd = settings?.restDayEnd ?? 6;
    return dayOfWeek >= restStart && dayOfWeek <= restEnd;
  }, [settings]);

  return (
    <ScheduleDashboardLayout>
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">
                {isRestDay ? "Rest Day" : "Today's Schedule"}
              </h1>
              <p className="text-muted-foreground mt-1">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
            </div>
            <Button onClick={() => navigate("/planner")} className="gap-2">
              <Plus size={18} />
              Add Schedule
            </Button>
          </div>

          {/* Rest Day Notice */}
          {isRestDay && (
            <Card className="bg-yellow-500/10 border-yellow-500/30 p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="text-yellow-600 dark:text-yellow-400 mt-0.5" size={20} />
                <div>
                  <p className="font-medium text-yellow-900 dark:text-yellow-200">Rest Day</p>
                  <p className="text-sm text-yellow-800 dark:text-yellow-300">
                    Take it easy today! Consider light activities only.
                  </p>
                </div>
              </div>
            </Card>
          )}

          {/* Energy Selector */}
          <EnergySelector />

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Sleep Summary */}
            <Card className="p-4 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Sleep Scheduled</p>
                  <p className="text-2xl font-bold text-foreground mt-1">
                    {sleepSummary.hours}h {sleepSummary.minutes}m
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    {sleepSummary.blocks} block{sleepSummary.blocks !== 1 ? "s" : ""}
                  </p>
                </div>
                <Moon className="text-blue-500" size={32} />
              </div>
            </Card>

            {/* Today's Events */}
            <Card className="p-4 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Today's Events</p>
                  <p className="text-2xl font-bold text-foreground mt-1">{todaySchedules.length}</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    {todaySchedules.filter((s) => s.type === "work").length} work,{" "}
                    {todaySchedules.filter((s) => s.type === "school").length} school
                  </p>
                </div>
                <Clock className="text-purple-500" size={32} />
              </div>
            </Card>

            {/* Next Deadline */}
            <Card className="p-4 border border-border">
              <div>
                <p className="text-sm text-muted-foreground">Next Deadline</p>
                {nextDeadline && timeUntilDeadline ? (
                  <>
                    <p className="text-2xl font-bold text-foreground mt-1">
                      {timeUntilDeadline.days}d {timeUntilDeadline.hours % 24}h
                    </p>
                    <p className="text-xs text-muted-foreground mt-2 truncate">
                      {nextDeadline.title}
                    </p>
                  </>
                ) : (
                  <p className="text-lg text-muted-foreground mt-1">No deadlines</p>
                )}
              </div>
            </Card>
          </div>

          {/* Today's Schedule */}
          <div>
            <h2 className="text-xl font-bold text-foreground mb-4">Today's Timeline</h2>
            {todaySchedules.length > 0 ? (
              <div className="space-y-2">
                {todaySchedules
                  .sort((a, b) => a.startTime.localeCompare(b.startTime))
                  .map((schedule) => (
                    <Card key={schedule.id} className="p-4 border border-border">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div
                            className={`w-3 h-12 rounded schedule-block-${schedule.type}`}
                          />
                          <div>
                            <p className="font-medium text-foreground">{schedule.title}</p>
                            <p className="text-sm text-muted-foreground">
                              {schedule.startTime} - {schedule.endTime}
                            </p>
                            {schedule.notes && (
                              <p className="text-xs text-muted-foreground mt-1">{schedule.notes}</p>
                            )}
                          </div>
                        </div>
                        <div className={`px-3 py-1 rounded text-xs font-medium text-white schedule-block-${schedule.type}`}>
                          {schedule.type.charAt(0).toUpperCase() + schedule.type.slice(1)}
                        </div>
                      </div>
                    </Card>
                  ))}
              </div>
            ) : (
              <Card className="p-8 border border-border text-center">
                <p className="text-muted-foreground">No schedules for today</p>
                <Button
                  variant="outline"
                  onClick={() => navigate("/planner")}
                  className="mt-4"
                >
                  Add Schedule
                </Button>
              </Card>
            )}
          </div>

          {/* Self-Care Tracker */}
          <SelfCareTracker />

          {/* Upcoming Deadlines */}
          <div>
            <h2 className="text-xl font-bold text-foreground mb-4">Upcoming Deadlines</h2>
            {upcomingTasks.length > 0 ? (
              <div className="space-y-2">
                {upcomingTasks.map((task) => {
                  const daysUntil = Math.ceil(
                    (new Date(task.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
                  );
                  return (
                    <Card key={task.id} className={`task-card priority-${task.priority}`}>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-foreground">{task.title}</p>
                          <p className="text-sm text-muted-foreground">{task.subject}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Due: {format(new Date(task.dueDate), "MMM d, yyyy 'at' h:mm a")}
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-foreground">{daysUntil}</div>
                          <p className="text-xs text-muted-foreground">days left</p>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <Card className="p-8 border border-border text-center">
                <p className="text-muted-foreground">No upcoming deadlines</p>
              </Card>
            )}
          </div>
        </div>
      </div>
    </ScheduleDashboardLayout>
  );
}
