import React, { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import ScheduleDashboardLayout from "@/components/ScheduleDashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, X } from "lucide-react";
import { toast } from "sonner";

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const HOURS = Array.from({ length: 24 }, (_, i) => i);

const SCHEDULE_TYPES = [
  { value: "school", label: "School", color: "#3b82f6" },
  { value: "work", label: "Work", color: "#a855f7" },
  { value: "sleep", label: "Sleep", color: "#6b7280" },
  { value: "personal", label: "Personal", color: "#22c55e" },
];

interface ScheduleForm {
  title: string;
  type: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  notes: string;
}

export default function WeeklyPlanner() {
  const { data: schedules = [], refetch } = trpc.schedule.list.useQuery();
  const { data: settings } = trpc.settings.get.useQuery();
  const createScheduleMutation = trpc.schedule.create.useMutation();
  const deleteScheduleMutation = trpc.schedule.delete.useMutation();

  const [isOpen, setIsOpen] = useState(false);
  const [selectedDay, setSelectedDay] = useState(0);
  const [form, setForm] = useState<ScheduleForm>({
    title: "",
    type: "school",
    dayOfWeek: 0,
    startTime: "09:00",
    endTime: "10:00",
    notes: "",
  });

  const restDayStart = settings?.restDayStart ?? 5;
  const restDayEnd = settings?.restDayEnd ?? 6;

  const handleAddSchedule = async () => {
    if (!form.title || !form.startTime || !form.endTime) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      await createScheduleMutation.mutateAsync({
        title: form.title,
        type: form.type as any,
        dayOfWeek: form.dayOfWeek,
        startTime: form.startTime,
        endTime: form.endTime,
        color: SCHEDULE_TYPES.find((t) => t.value === form.type)?.color || "#3b82f6",
        notes: form.notes || undefined,
      });
      toast.success("Schedule added successfully");
      setIsOpen(false);
      setForm({
        title: "",
        type: "school",
        dayOfWeek: selectedDay,
        startTime: "09:00",
        endTime: "10:00",
        notes: "",
      });
      refetch();
    } catch (error) {
      toast.error("Failed to add schedule");
    }
  };

  const handleDeleteSchedule = async (id: number) => {
    try {
      await deleteScheduleMutation.mutateAsync({ id });
      toast.success("Schedule deleted");
      refetch();
    } catch (error) {
      toast.error("Failed to delete schedule");
    }
  };

  const getSchedulesForDayAndHour = (dayOfWeek: number, hour: number) => {
    return schedules.filter((s) => {
      if (s.dayOfWeek !== dayOfWeek) return false;
      const [startH] = s.startTime.split(":").map(Number);
      return startH === hour;
    });
  };

  const getScheduleColor = (type: string) => {
    const typeConfig = SCHEDULE_TYPES.find((t) => t.value === type);
    return typeConfig?.color || "#3b82f6";
  };

  return (
    <ScheduleDashboardLayout>
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-full mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Weekly Planner</h1>
              <p className="text-muted-foreground mt-1">Manage your weekly schedule</p>
            </div>
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus size={18} />
                  Add Schedule
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Schedule</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Title *</Label>
                    <Input
                      value={form.title}
                      onChange={(e) => setForm({ ...form, title: e.target.value })}
                      placeholder="e.g., Math Class"
                    />
                  </div>
                  <div>
                    <Label>Type *</Label>
                    <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {SCHEDULE_TYPES.map((t) => (
                          <SelectItem key={t.value} value={t.value}>
                            {t.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Day *</Label>
                    <Select value={form.dayOfWeek.toString()} onValueChange={(v) => setForm({ ...form, dayOfWeek: parseInt(v) })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {DAYS.map((day, idx) => (
                          <SelectItem key={idx} value={idx.toString()}>
                            {day}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Start Time *</Label>
                      <Input
                        type="time"
                        value={form.startTime}
                        onChange={(e) => setForm({ ...form, startTime: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label>End Time *</Label>
                      <Input
                        type="time"
                        value={form.endTime}
                        onChange={(e) => setForm({ ...form, endTime: e.target.value })}
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Notes</Label>
                    <Input
                      value={form.notes}
                      onChange={(e) => setForm({ ...form, notes: e.target.value })}
                      placeholder="Optional notes"
                    />
                  </div>
                  <Button onClick={handleAddSchedule} className="w-full">
                    Add Schedule
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-4">
            {SCHEDULE_TYPES.map((type) => (
              <div key={type.value} className="flex items-center gap-2">
                <div
                  className="w-4 h-4 rounded"
                  style={{ backgroundColor: type.color }}
                />
                <span className="text-sm text-muted-foreground">{type.label}</span>
              </div>
            ))}
          </div>

          {/* Weekly Grid */}
          <div className="overflow-x-auto">
            <div className="min-w-full">
              {/* Header with days */}
              <div className="grid grid-cols-8 gap-2 mb-4">
                <div className="w-20" />
                {DAYS.map((day, idx) => {
                  const isRestDay = idx >= restDayStart && idx <= restDayEnd;
                  return (
                    <div
                      key={idx}
                      className={`p-3 rounded-lg border border-border text-center ${
                        isRestDay ? "bg-muted/50" : "bg-card"
                      }`}
                    >
                      <p className="font-bold text-foreground">{day}</p>
                      {isRestDay && (
                        <p className="text-xs text-muted-foreground mt-1">Rest Day</p>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Timeline */}
              <div className="space-y-2">
                {HOURS.map((hour) => (
                  <div key={hour} className="grid grid-cols-8 gap-2">
                    <div className="w-20 pt-2 text-xs text-muted-foreground font-medium">
                      {String(hour).padStart(2, "0")}:00
                    </div>
                    {DAYS.map((_, dayIdx) => {
                      const daySchedules = getSchedulesForDayAndHour(dayIdx, hour);
                      const isRestDay = dayIdx >= restDayStart && dayIdx <= restDayEnd;

                      return (
                        <div
                          key={`${dayIdx}-${hour}`}
                          className={`min-h-16 border border-border rounded-lg p-2 ${
                            isRestDay ? "bg-muted/30" : "bg-card"
                          }`}
                        >
                          {daySchedules.map((schedule) => (
                            <div
                              key={schedule.id}
                              className="schedule-block mb-1 relative group"
                              style={{ backgroundColor: schedule.color }}
                            >
                              <div className="flex items-start justify-between gap-1">
                                <div className="flex-1 min-w-0">
                                  <p className="text-xs font-medium truncate">{schedule.title}</p>
                                  <p className="text-xs opacity-90">
                                    {schedule.startTime} - {schedule.endTime}
                                  </p>
                                </div>
                                <button
                                  onClick={() => handleDeleteSchedule(schedule.id)}
                                  className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-black/20 rounded"
                                >
                                  <X size={14} />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Tips */}
          <Card className="p-4 bg-blue-500/10 border-blue-500/30">
            <p className="text-sm text-blue-900 dark:text-blue-200">
              💡 <strong>Tip:</strong> Schedule your sleep blocks after night shifts to maintain healthy sleep patterns. The system will help you track rest time.
            </p>
          </Card>
        </div>
      </div>
    </ScheduleDashboardLayout>
  );
}
