import React, { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import ScheduleDashboardLayout from "@/components/ScheduleDashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Trash2, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { format, differenceInHours, differenceInDays } from "date-fns";

const TASK_TYPES = ["essay", "reading", "exam", "presentation", "other"];
const PRIORITIES = ["low", "medium", "high"];

interface TaskForm {
  subject: string;
  title: string;
  type: string;
  dueDate: string;
  dueTime: string;
  priority: string;
  description: string;
}

export default function Tasks() {
  const { data: tasks = [], refetch } = trpc.task.list.useQuery();
  const { data: schedules = [] } = trpc.schedule.list.useQuery();
  const createTaskMutation = trpc.task.create.useMutation();
  const updateTaskMutation = trpc.task.update.useMutation();
  const deleteTaskMutation = trpc.task.delete.useMutation();

  const [isOpen, setIsOpen] = useState(false);
  const [filterPriority, setFilterPriority] = useState<string>("all");
  const [filterSubject, setFilterSubject] = useState<string>("all");
  const [form, setForm] = useState<TaskForm>({
    subject: "",
    title: "",
    type: "essay",
    dueDate: "",
    dueTime: "23:59",
    priority: "medium",
    description: "",
  });

  const subjects = useMemo(() => {
    const unique = new Set(tasks.map((t) => t.subject));
    return Array.from(unique).sort();
  }, [tasks]);

  const filteredTasks = useMemo(() => {
    return tasks.filter((task) => {
      if (filterPriority !== "all" && task.priority !== filterPriority) return false;
      if (filterSubject !== "all" && task.subject !== filterSubject) return false;
      return true;
    });
  }, [tasks, filterPriority, filterSubject]);

  const sortedTasks = useMemo(() => {
    return filteredTasks.sort((a, b) => {
      // Incomplete first, then by due date
      if (a.isCompleted !== b.isCompleted) {
        return a.isCompleted ? 1 : -1;
      }
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    });
  }, [filteredTasks]);

  // Check for deadline conflicts with work shifts
  const checkDeadlineConflicts = (dueDate: string, dueTime: string) => {
    const taskDue = new Date(`${dueDate}T${dueTime}`);
    const conflicts: any[] = [];

    schedules.forEach((schedule) => {
      if (schedule.type === "work") {
        const [startH, startM] = schedule.startTime.split(":").map(Number);
        const [endH, endM] = schedule.endTime.split(":").map(Number);

        // Simple check - if task is due during work hours
        const taskHour = taskDue.getHours();
        const taskMin = taskDue.getMinutes();

        let scheduleStart = startH * 60 + startM;
        let scheduleEnd = endH * 60 + endM;
        let taskTime = taskHour * 60 + taskMin;

        if (scheduleEnd < scheduleStart) {
          // Overnight shift
          if (taskTime >= scheduleStart || taskTime <= scheduleEnd) {
            conflicts.push(schedule);
          }
        } else {
          if (taskTime >= scheduleStart && taskTime <= scheduleEnd) {
            conflicts.push(schedule);
          }
        }
      }
    });

    return conflicts;
  };

  const handleAddTask = async () => {
    if (!form.subject || !form.title || !form.dueDate) {
      toast.error("Please fill in all required fields");
      return;
    }

    const conflicts = checkDeadlineConflicts(form.dueDate, form.dueTime);
    if (conflicts.length > 0) {
      toast.warning(
        `This deadline overlaps with ${conflicts.length} work shift(s). You may want to adjust the time.`
      );
    }

    try {
      const dueDateTime = new Date(`${form.dueDate}T${form.dueTime}`);
      await createTaskMutation.mutateAsync({
        subject: form.subject,
        title: form.title,
        type: form.type as any,
        dueDate: dueDateTime,
        priority: form.priority as any,
        description: form.description || undefined,
      });
      toast.success("Task added successfully");
      setIsOpen(false);
      setForm({
        subject: "",
        title: "",
        type: "essay",
        dueDate: "",
        dueTime: "23:59",
        priority: "medium",
        description: "",
      });
      refetch();
    } catch (error) {
      toast.error("Failed to add task");
    }
  };

  const handleToggleComplete = async (taskId: number, isCompleted: boolean) => {
    try {
      await updateTaskMutation.mutateAsync({
        id: taskId,
        isCompleted: !isCompleted,
      });
      refetch();
    } catch (error) {
      toast.error("Failed to update task");
    }
  };

  const handleDeleteTask = async (taskId: number) => {
    try {
      await deleteTaskMutation.mutateAsync({ id: taskId });
      toast.success("Task deleted");
      refetch();
    } catch (error) {
      toast.error("Failed to delete task");
    }
  };

  const getTimeUntil = (dueDate: Date) => {
    const now = new Date();
    const days = differenceInDays(dueDate, now);
    const hours = differenceInHours(dueDate, now) % 24;

    if (days > 0) {
      return `${days}d ${hours}h left`;
    } else if (hours > 0) {
      return `${hours}h left`;
    } else {
      return "Due soon!";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "text-red-600 dark:text-red-400";
      case "medium":
        return "text-yellow-600 dark:text-yellow-400";
      case "low":
        return "text-green-600 dark:text-green-400";
      default:
        return "text-muted-foreground";
    }
  };

  return (
    <ScheduleDashboardLayout>
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Tasks & Deadlines</h1>
              <p className="text-muted-foreground mt-1">
                {sortedTasks.filter((t) => !t.isCompleted).length} active tasks
              </p>
            </div>
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus size={18} />
                  Add Task
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Add New Task</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Subject *</Label>
                    <Input
                      value={form.subject}
                      onChange={(e) => setForm({ ...form, subject: e.target.value })}
                      placeholder="e.g., English Literature"
                    />
                  </div>
                  <div>
                    <Label>Task Title *</Label>
                    <Input
                      value={form.title}
                      onChange={(e) => setForm({ ...form, title: e.target.value })}
                      placeholder="e.g., Essay on Shakespeare"
                    />
                  </div>
                  <div>
                    <Label>Task Type *</Label>
                    <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {TASK_TYPES.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type.charAt(0).toUpperCase() + type.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Priority *</Label>
                    <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PRIORITIES.map((p) => (
                          <SelectItem key={p} value={p}>
                            {p.charAt(0).toUpperCase() + p.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Due Date *</Label>
                      <Input
                        type="date"
                        value={form.dueDate}
                        onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label>Due Time</Label>
                      <Input
                        type="time"
                        value={form.dueTime}
                        onChange={(e) => setForm({ ...form, dueTime: e.target.value })}
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Description</Label>
                    <Input
                      value={form.description}
                      onChange={(e) => setForm({ ...form, description: e.target.value })}
                      placeholder="Optional notes"
                    />
                  </div>
                  <Button onClick={handleAddTask} className="w-full">
                    Add Task
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-48">
              <Label className="text-xs text-muted-foreground mb-2 block">Filter by Subject</Label>
              <Select value={filterSubject} onValueChange={setFilterSubject}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Subjects</SelectItem>
                  {subjects.map((subject) => (
                    <SelectItem key={subject} value={subject}>
                      {subject}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1 min-w-48">
              <Label className="text-xs text-muted-foreground mb-2 block">Filter by Priority</Label>
              <Select value={filterPriority} onValueChange={setFilterPriority}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Priorities</SelectItem>
                  {PRIORITIES.map((p) => (
                    <SelectItem key={p} value={p}>
                      {p.charAt(0).toUpperCase() + p.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Tasks List */}
          <div className="space-y-3">
            {sortedTasks.length > 0 ? (
              sortedTasks.map((task) => {
                const dueDate = new Date(task.dueDate);
                const conflicts = checkDeadlineConflicts(
                  dueDate.toISOString().split("T")[0],
                  String(dueDate.getHours()).padStart(2, "0") +
                    ":" +
                    String(dueDate.getMinutes()).padStart(2, "0")
                );

                return (
                  <Card
                    key={task.id}
                    className={`task-card priority-${task.priority} ${
                      task.isCompleted ? "opacity-60" : ""
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <Checkbox
                        checked={task.isCompleted === 1}
                        onCheckedChange={() => handleToggleComplete(task.id, task.isCompleted === 1)}
                        className="mt-1"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p
                              className={`font-medium ${
                                task.isCompleted ? "line-through text-muted-foreground" : "text-foreground"
                              }`}
                            >
                              {task.title}
                            </p>
                            <p className="text-sm text-muted-foreground mt-1">{task.subject}</p>
                            {task.description && (
                              <p className="text-sm text-muted-foreground mt-2">{task.description}</p>
                            )}
                          </div>
                          <div className="text-right flex-shrink-0">
                            <p className={`text-xs font-medium ${getPriorityColor(task.priority)}`}>
                              {task.priority.toUpperCase()}
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {format(dueDate, "MMM d, yyyy")}
                            </p>
                            <p className="text-xs font-medium text-foreground mt-1">
                              {getTimeUntil(dueDate)}
                            </p>
                          </div>
                        </div>

                        {/* Conflict Warning */}
                        {conflicts.length > 0 && !task.isCompleted && (
                          <div className="mt-3 flex items-start gap-2 p-2 bg-red-500/10 rounded border border-red-500/30">
                            <AlertCircle size={16} className="text-red-600 dark:text-red-400 mt-0.5 flex-shrink-0" />
                            <p className="text-xs text-red-700 dark:text-red-300">
                              Deadline conflicts with {conflicts.length} work shift(s)
                            </p>
                          </div>
                        )}
                      </div>
                      <button
                        onClick={() => handleDeleteTask(task.id)}
                        className="p-2 hover:bg-red-500/10 rounded transition-colors flex-shrink-0"
                      >
                        <Trash2 size={18} className="text-red-500" />
                      </button>
                    </div>
                  </Card>
                );
              })
            ) : (
              <Card className="p-8 border border-border text-center">
                <p className="text-muted-foreground">No tasks yet</p>
                <Button
                  variant="outline"
                  onClick={() => setIsOpen(true)}
                  className="mt-4"
                >
                  Create your first task
                </Button>
              </Card>
            )}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mt-8">
            <Card className="p-4 border border-border">
              <p className="text-sm text-muted-foreground">Total Tasks</p>
              <p className="text-2xl font-bold text-foreground mt-2">{tasks.length}</p>
            </Card>
            <Card className="p-4 border border-border">
              <p className="text-sm text-muted-foreground">Completed</p>
              <p className="text-2xl font-bold text-green-600 dark:text-green-400 mt-2">
                {tasks.filter((t) => t.isCompleted).length}
              </p>
            </Card>
            <Card className="p-4 border border-border">
              <p className="text-sm text-muted-foreground">Remaining</p>
              <p className="text-2xl font-bold text-orange-600 dark:text-orange-400 mt-2">
                {tasks.filter((t) => !t.isCompleted).length}
              </p>
            </Card>
          </div>
        </div>
      </div>
    </ScheduleDashboardLayout>
  );
}
