import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Calendar, Clock, AlertCircle, Moon, CheckSquare, Settings } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Home() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (isAuthenticated) {
      navigate("/");
    }
  }, [isAuthenticated, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background">
      {/* Navigation */}
      <nav className="border-b border-border">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="text-blue-500" size={28} />
            <h1 className="text-2xl font-bold text-foreground">Schedule Manager</h1>
          </div>
          <Button asChild>
            <a href={getLoginUrl()}>Login</a>
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-4 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-5xl font-bold text-foreground mb-6">
              Master Your Schedule,<br />
              <span className="text-blue-500">Balance Your Life</span>
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              A student-friendly schedule management system designed to help my girlfriend effectively balance school, work, and personal life especially suited for a graveyard shift schedule.
            </p>
            <div className="flex gap-4">
              <Button size="lg" asChild>
                <a href={getLoginUrl()}>Get Started</a>
              </Button>
              <Button size="lg" variant="outline">
                Learn More
              </Button>
            </div>
          </div>
          <div className="space-y-4">
            <Card className="p-6 border border-border">
              <Calendar className="text-blue-500 mb-3" size={24} />
              <h3 className="font-bold text-foreground mb-2">Smart Weekly View</h3>
              <p className="text-sm text-muted-foreground">
                Color-coded schedule blocks for school, work, sleep, and deadlines. Supports overnight schedules seamlessly.
              </p>
            </Card>
            <Card className="p-6 border border-border">
              <CheckSquare className="text-green-500 mb-3" size={24} />
              <h3 className="font-bold text-foreground mb-2">Task Manager</h3>
              <p className="text-sm text-muted-foreground">
                Track assignments, exams, and presentations with priority levels and deadline countdowns.
              </p>
            </Card>
            <Card className="p-6 border border-border">
              <Moon className="text-purple-500 mb-3" size={24} />
              <h3 className="font-bold text-foreground mb-2">Graveyard Shift Friendly</h3>
              <p className="text-sm text-muted-foreground">
                Automatic sleep suggestions and rest day awareness to prevent burnout.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-card border-y border-border py-20">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-foreground mb-12 text-center">
            Everything You Need to Stay Organized
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-lg bg-blue-500/20 flex items-center justify-center">
                <Calendar className="text-blue-500" size={24} />
              </div>
              <h3 className="font-bold text-foreground">Weekly Planner</h3>
              <p className="text-sm text-muted-foreground">
                View your entire week at a glance with color-coded time blocks for different activities.
              </p>
            </div>
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-lg bg-purple-500/20 flex items-center justify-center">
                <Clock className="text-purple-500" size={24} />
              </div>
              <h3 className="font-bold text-foreground">Smart Notifications</h3>
              <p className="text-sm text-muted-foreground">
                Get reminders 24 hours and 3 hours before deadlines, plus class reminders 30 minutes before.
              </p>
            </div>
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-lg bg-red-500/20 flex items-center justify-center">
                <AlertCircle className="text-red-500" size={24} />
              </div>
              <h3 className="font-bold text-foreground">Conflict Detection</h3>
              <p className="text-sm text-muted-foreground">
                Automatic warnings when deadlines clash with your work shifts.
              </p>
            </div>
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-lg bg-green-500/20 flex items-center justify-center">
                <CheckSquare className="text-green-500" size={24} />
              </div>
              <h3 className="font-bold text-foreground">Task Management</h3>
              <p className="text-sm text-muted-foreground">
                Organize tasks by subject, type, and priority with countdown indicators.
              </p>
            </div>
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                <Moon className="text-yellow-500" size={24} />
              </div>
              <h3 className="font-bold text-foreground">Rest Day Awareness</h3>
              <p className="text-sm text-muted-foreground">
                Automatic rest day marking and gentle burnout prevention reminders.
              </p>
            </div>
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-lg bg-blue-500/20 flex items-center justify-center">
                <Settings className="text-blue-500" size={24} />
              </div>
              <h3 className="font-bold text-foreground">Customizable Settings</h3>
              <p className="text-sm text-muted-foreground">
                Configure work shifts, rest days, and notification preferences to match your lifestyle.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* User Profile Section */}
      <section className="max-w-6xl mx-auto px-4 py-20">
        <div className="bg-card border border-border rounded-lg p-12">
          <h2 className="text-3xl font-bold text-foreground mb-6">Built for Cai</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-bold text-foreground mb-4">Your Profile</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500" />
                  <span>3rd Year ABELS Student at PUP Manila</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-500" />
                  <span>Working Student at Alorica by the Bay</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-gray-500" />
                  <span>Graveyard Shift (7:30 PM - 4:30 AM)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-500" />
                  <span>Rest Days: Saturday & Sunday</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-bold text-foreground mb-4">Why This App?</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-blue-500 font-bold mt-1">✓</span>
                  <span>Reduce cognitive overload with a clean, intuitive interface</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-500 font-bold mt-1">✓</span>
                  <span>Never miss a deadline with smart conflict detection</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-500 font-bold mt-1">✓</span>
                  <span>Track sleep and rest to prevent burnout</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-500 font-bold mt-1">✓</span>
                  <span>Designed for overnight schedules from day one</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-card border-t border-border py-20">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-foreground mb-6">
            Ready to Take Control of Your Schedule?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Start organizing your week in under 10 minutes. No credit card required.
          </p>
          <Button size="lg" asChild>
            <a href={getLoginUrl()}>Get Started Now</a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="max-w-6xl mx-auto px-4 text-center text-muted-foreground text-sm">
          <p>Schedule Management System MVP • Built for working students</p>
        </div>
      </footer>
    </div>
  );
}
